package testProject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class ALexercises {

	public static void main(String[] args) {
		// Joao Vitor Souza Pioner
		Scanner scan = new Scanner(System.in);
		System.out.print("Por favor, insira o tamanho do ArrayList: ");
		int n = scan.nextInt();

		var list = new ArrayList<Integer>();
		if (n >= 0) {
			for (int i = 0; i < n; i++) {
				int numb = scan.nextInt();
				list.add(numb);
			}
		} else {
			System.out.println("O numero precisa ser > ou = a 0.");
		}
		int highestNumber =  Collections.max(list); //it gets the highest number inside the list
		int[] armazenador = new int[list.size()];
		
		for (int i = 0; i < n;i++) {
			armazenador[i] = list.get(i)/highestNumber;
		}
		System.out.println("Itens contidos no array: "+Arrays.toString(armazenador));
	}

}
/*
 * Fazer um método que lê N números inteiros positivos (para quando nro<0) e
 * aramazena-os em um ArrayList. Dividir todos os seus elementos pelo maior
 * valor, armazenando os resultados em um vetor. Exibir o vetor resultante.
 */